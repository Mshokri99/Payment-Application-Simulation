#include "app.h"

void main(void)
{
	
	appStart();
	printf("\n********END PROGRAM********\n");
} 
