#ifndef _APP_H_
#define _APP_H_
#include <stdio.h>
#include "card.h"
#include "terminal.h"
#include "server.h"


void appStart(void);


#endif
